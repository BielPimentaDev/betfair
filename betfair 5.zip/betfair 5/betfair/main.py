from lib.bot import bot

if __name__ == "__main__":
    """
    above - acima de 2.5 gols
    tie - soma do total de gols igual a 2
    visitor - visitante vence
    coef - coeficiente multiplicador do martingale
    value - aposta inicial
    martingale - numero de jogos martingale
    enabled - se a linha era executar ou nao
    stop_param_lose - valor de parada em perdas
    stop_param_win - valor de parada em ganhos
    stop_time - tempo de espera para reiniciar em minutos
    """
    body = {
            "above": {"coef": 1.55, "value": 0.77, "martingale": 3, "enabled": True},
            "tie": {"coef": 1.55, "value": 0.77, "martingale": 3, "enabled": True},
            "visitor": {"coef": 1, "value": 1, "martingale": 2, "enabled": True},
            "stop_param_lose": -0.5,
            "stop_param_win": 0.5,
            "stop_time": 180,
        }
    
    bot(body)




   